"""
PART 1 · 理论基座 (P06-P20)
含：章节封面 + MaxKB 是啥 + 架构 + 五维能力 + RAG + RAG 对比 +
LangChain + 向量化 + Workflow + MCP + Agent 范式 + 技术栈剖析 +
理论总结
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from helpers import *

IMG_DIR = "/root/.openclaw/workspace/projects/MaxKB教学案例/images"
TOTAL = '64'

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank_layout = prs.slide_layouts[6]

page = 0

# ---- P06 章节分隔页 · 理论基座 ----
page = 6
slide = prs.slides.add_slide(blank_layout)
add_section_cover(slide, '01', '理论基座 · 从 0 到 1 理解 MaxKB',
                  page, TOTAL,
                  subtitle='本部分用 5 个章节讲清楚：\nMaxKB 是什么、解决什么问题\nRAG / LangChain / 向量化等核心原理\nWorkflow / MCP / Agent 范式\nDjango + Vue + pgvector 技术栈剖析\n帮助师生建立完整的理论地图')
add_footer(slide, page, TOTAL)


# ---- P07 MaxKB 是什么 ----
page = 7
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.1 MaxKB 是什么？', font_size=40, font_color=PURPLE_DEEP, bold=True)
add_rect(slide, Inches(0.5), Inches(2.2), Inches(6), Inches(4.5), LIGHT_GRAY)
add_text(slide, Inches(0.8), Inches(2.5), Inches(5.5), Inches(1.5),
         'MaxKB', font_size=60, font_color=PURPLE_DEEP, bold=True)
add_text(slide, Inches(0.8), Inches(3.6), Inches(5.5), Inches(0.5),
         '= Max Knowledge Brain', font_size=20, font_color=BLUE_DEEP, bold=True)
add_text(slide, Inches(0.8), Inches(4.4), Inches(5.5), Inches(2.5),
         '一款强大易用的开源企业级智能体平台，\n致力于解决企业 AI 落地的\n「高门槛 · 高成本 · 长周期」三大难题。',
         font_size=14, font_color=DARK_GRAY)
add_text(slide, Inches(0.8), Inches(6.2), Inches(5.5), Inches(0.5),
         '⭐ GitHub · 开源 · GPL v3 · Docker 一键启动',
         font_size=11, font_color=PURPLE, italic=True)
add_text(slide, Inches(7.0), Inches(2.2), Inches(6), Inches(0.5),
         '📊 核心数据（2026 年）', font_size=18, font_color=PURPLE, bold=True)
stats = [('10K+', 'GitHub Stars'), ('100+', '企业生产用例'),
         ('20+', '支持 LLM 模型'), ('v2.0', '当前版本')]
for i, (n, label) in enumerate(stats):
    row, col = i // 2, i % 2
    x, y = Inches(7.0 + 3.0 * col), Inches(3.0 + 1.7 * row)
    add_rounded(slide, x, y, Inches(2.8), Inches(1.5), WHITE)
    # 上边框（紫色描边）
    rect = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, Inches(2.8), Inches(1.5))
    rect.fill.background()
    rect.line.color.rgb = PURPLE_LIGHT
    rect.line.width = Pt(1.5)
    rect.shadow.inherit = False
    add_text(slide, x, y + Inches(0.2), Inches(2.8), Inches(0.7),
             n, font_size=32, font_color=PURPLE_DEEP, bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, x, y + Inches(0.95), Inches(2.8), Inches(0.4),
             label, font_size=12, font_color=MID_GRAY, align=PP_ALIGN.CENTER)
add_footer(slide, page, TOTAL)


# ---- P08 MaxKB 核心架构 ----
page = 8
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.2 MaxKB 核心架构', font_size=40, font_color=PURPLE_DEEP, bold=True)
slide.shapes.add_picture(f'{IMG_DIR}/04_三层架构图.png',
                         Inches(0.3), Inches(2.0), width=Inches(8.0))
add_text(slide, Inches(9.0), Inches(2.0), Inches(4), Inches(0.5),
         '📌 三大层级', font_size=18, font_color=PURPLE, bold=True)
layers = [
    ('应用层', 'Vue.js · Web 控制台、嵌入组件', PURPLE),
    ('服务层', 'Django + LangChain · RAG / Workflow / MCP', BLUE),
    ('基础层', 'PostgreSQL + pgvector + 多 LLM', BLUE_DEEP),
]
for i, (name, desc, c) in enumerate(layers):
    y = Inches(2.7 + 0.9 * i)
    add_rect(slide, Inches(9.0), y, Inches(0.1), Inches(0.7), c)
    add_text(slide, Inches(9.2), y, Inches(4), Inches(0.4),
             name, font_size=14, font_color=c, bold=True)
    add_text(slide, Inches(9.2), y + Inches(0.35), Inches(4), Inches(0.5),
             desc, font_size=11, font_color=DARK_GRAY)
add_rect(slide, Inches(0.5), Inches(6.5), Inches(12.3), Inches(0.5), LIGHT_GRAY)
add_text(slide, Inches(0.7), Inches(6.55), Inches(12), Inches(0.4),
         '⚡ 三层解耦是 MaxKB 可扩展性的核心：UI 层可换实现 · 服务层可水平扩展 · 基础层可替换组件',
         font_size=12, font_color=PURPLE_DEEP, italic=True, bold=True)
add_footer(slide, page, TOTAL)


# ---- P09 MaxKB 五维能力 ----
page = 9
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.3 MaxKB 五维核心能力', font_size=40, font_color=PURPLE_DEEP, bold=True)
slide.shapes.add_picture(f'{IMG_DIR}/01_五维能力雷达图.png',
                         Inches(0.3), Inches(2.0), height=Inches(5.0))
add_text(slide, Inches(8.0), Inches(2.0), Inches(5), Inches(0.5),
         '📊 五大能力维度', font_size=18, font_color=PURPLE, bold=True)
caps = [
    ('RAG 检索', '⭐⭐⭐⭐⭐', '文档 → 向量化 → 召回 → 重排'),
    ('工作流', '⭐⭐⭐⭐', '可视化拖拽 + 自定义节点'),
    ('MCP 工具', '⭐⭐⭐⭐⭐', '标准化协议接入外部工具'),
    ('模型中立', '⭐⭐⭐⭐⭐', '20+ LLM 模型自由切换'),
    ('多模态', '⭐⭐⭐⭐', '文本/图像/音频/视频'),
]
for i, (name, star, desc) in enumerate(caps):
    y = Inches(2.7 + 0.8 * i)
    add_text(slide, Inches(8.0), y, Inches(2.0), Inches(0.4),
             name, font_size=14, font_color=PURPLE_DEEP, bold=True)
    add_text(slide, Inches(10.0), y, Inches(1.5), Inches(0.4),
             star, font_size=13, font_color=YELLOW)
    add_text(slide, Inches(8.0), y + Inches(0.4), Inches(5), Inches(0.4),
             desc, font_size=11, font_color=DARK_GRAY)
add_footer(slide, page, TOTAL)


# ---- P10 RAG 原理 ----
page = 10
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.4 RAG · 检索增强生成原理', font_size=40, font_color=PURPLE_DEEP, bold=True)
slide.shapes.add_picture(f'{IMG_DIR}/02_RAG原理流程图.png',
                         Inches(0.3), Inches(2.0), width=Inches(12.7))
add_rect(slide, Inches(0.5), Inches(6.0), Inches(12.3), Inches(1.0), PURPLE_LIGHT)
add_text(slide, Inches(0.7), Inches(6.1), Inches(12), Inches(0.5),
         '💡 核心要点', font_size=14, font_color=PURPLE_DEEP, bold=True)
add_text(slide, Inches(0.7), Inches(6.45), Inches(12), Inches(0.5),
         'RAG 让 LLM「带着事实作答」，相比直接问 LLM，幻觉率下降 70%+，回答准确率提升 60%+',
         font_size=13, font_color=DARK_GRAY)
add_footer(slide, page, TOTAL)


# ---- P11 RAG vs 传统问答 ----
page = 11
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.5 RAG vs 传统 LLM 问答', font_size=40, font_color=PURPLE_DEEP, bold=True)

# 左侧 坏
add_rect(slide, Inches(0.5), Inches(2.2), Inches(6), Inches(4.5), LIGHT_GRAY)
add_text(slide, Inches(0.7), Inches(2.4), Inches(5.6), Inches(0.6),
         '❌ 传统 LLM 问答', font_size=22, font_color=MID_GRAY, bold=True)
add_rect(slide, Inches(0.7), Inches(3.05), Inches(1.0), Inches(0.05), MID_GRAY)
bad = ['❌ 知识截止，答不上最新事件', '❌ 凭空捏造，幻觉率高',
       '❌ 私域知识，无法访问', '❌ 来源不明，难以审计']
for i, p in enumerate(bad):
    add_text(slide, Inches(0.7), Inches(3.4 + 0.5 * i), Inches(5.5), Inches(0.4),
             p, font_size=13, font_color=DARK_GRAY)

# 右侧 好
add_rect(slide, Inches(6.8), Inches(2.2), Inches(6), Inches(4.5), PURPLE_LIGHT)
add_text(slide, Inches(7.0), Inches(2.4), Inches(5.6), Inches(0.6),
         '✅ RAG 增强问答', font_size=22, font_color=PURPLE_DEEP, bold=True)
add_rect(slide, Inches(7.0), Inches(3.05), Inches(1.0), Inches(0.05), PURPLE_DEEP)
good = ['✅ 知识实时更新，跟上最新', '✅ 引用文档，幻觉大幅下降',
        '✅ 加载私域文档，专业能力', '✅ 引用溯源，可信可审计']
for i, p in enumerate(good):
    add_text(slide, Inches(7.0), Inches(3.4 + 0.5 * i), Inches(5.5), Inches(0.4),
             p, font_size=13, font_color=DARK_GRAY)

# 底部
add_rect(slide, Inches(0.5), Inches(6.8), Inches(12.3), Inches(0.4), BLUE_DEEP)
add_text(slide, Inches(0.7), Inches(6.85), Inches(12), Inches(0.3),
         '⚡ MaxKB 默认采用 RAG 范式，文档先切片、再向量化、最后检索增强生成',
         font_size=11, font_color=WHITE, bold=True)
add_footer(slide, page, TOTAL)


# ---- P12 RAG 核心代码演示 ----
page = 12
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.6 RAG 核心代码演示', font_size=40, font_color=PURPLE_DEEP, bold=True)
add_code(slide, Inches(0.5), Inches(2.2), Inches(12.3), Inches(4.5), '''
def rag_qa(query: str, knowledge_base: list, llm) -> str:
    """RAG 核心 4 步：召回 → 组装 → 生成"""
    # Step 1: 检索 Top-K 相关文档片段
    chunks = vector_search(query, kb=knowledge_base, top_k=5)
    # Step 2: 重排（Rerank）
    reranked = reranker(query, chunks)
    # Step 3: 拼接 Prompt
    context = "\\n---\\n".join([c.text for c in reranked])
    prompt = f"""基于以下上下文回答问题，引用内容必须忠实：

{context}

问题：{query}
回答："""
    # Step 4: LLM 生成
    answer = llm.invoke(prompt)
    return answer
''', lang='python')
add_rect(slide, Inches(0.5), Inches(7.0), Inches(12.3), Inches(0.4), PURPLE_LIGHT)
add_text(slide, Inches(0.7), Inches(7.05), Inches(12), Inches(0.3),
         '💡 MaxKB 内部实现比这个更复杂（含权限控制 / 多路召回 / 流式输出）',
         font_size=11, font_color=PURPLE_DEEP, bold=True)
add_footer(slide, page, TOTAL)


# ---- P13 向量化与 pgvector ----
page = 13
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.7 向量化与 pgvector', font_size=40, font_color=PURPLE_DEEP, bold=True)

# 左侧 - 向量化原理
add_text(slide, Inches(0.5), Inches(2.2), Inches(6), Inches(0.5),
         '🔮 什么是向量化？', font_size=18, font_color=PURPLE, bold=True)
add_card(slide, Inches(0.5), Inches(2.8), Inches(6.0), Inches(3.5),
         '语义 → 数字', [
             '文本通过 Embedding 模型映射到 N 维空间',
             '语义相近 → 向量距离近（余弦相似度）',
             '"苹果手机" 和 "iPhone" 距离很近',
             '"苹果手机" 和 "红富士苹果" 距离较远',
         ], accent_color=PURPLE)
add_card(slide, Inches(0.5), Inches(6.4), Inches(6.0), Inches(0.6),
         '常用模型', ['bge-large-zh · text-embedding-ada-002 · m3e · bce'], accent_color=BLUE)

# 右侧 - pgvector
add_text(slide, Inches(7.0), Inches(2.2), Inches(6), Inches(0.5),
         '🗄️ 为什么用 pgvector？', font_size=18, font_color=BLUE, bold=True)
add_card(slide, Inches(7.0), Inches(2.8), Inches(6.0), Inches(3.5),
         'PostgreSQL 扩展', [
             '在 PostgreSQL 上原生支持向量存储',
             '支持 1024 / 1536 / 3072 维向量',
             '使用 IVFFlat / HNSW 索引加速检索',
             '事务一致，备份简单，运维熟悉',
         ], accent_color=BLUE_DEEP)
add_text(slide, Inches(7.0), Inches(6.5), Inches(6), Inches(0.5),
         '⚡ MaxKB 默认使用 PostgreSQL + pgvector，无需引入额外的向量数据库',
         font_size=11, font_color=PURPLE, italic=True, bold=True)
add_footer(slide, page, TOTAL)


# ---- P14 嵌入与检索代码 ----
page = 14
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.8 嵌入与检索代码示例', font_size=40, font_color=PURPLE_DEEP, bold=True)
add_code(slide, Inches(0.5), Inches(2.2), Inches(12.3), Inches(4.5), '''
# === 1. 文档向量化入库 ===
from langchain.vectorstores import PGVector
from langchain.embeddings import OpenAIEmbeddings

emb = OpenAIEmbeddings(model="text-embedding-3-small")
vector_store = PGVector.from_documents(
    documents=docs,
    embedding=emb,
    connection_string="postgresql://user:pwd@localhost/maxkb",
    pre_delete_collection=True,
)
print(f"已入库 {len(docs)} 个文档")

# === 2. 相似度检索 ===
query = "MaxKB 的核心特性"
results = vector_store.similarity_search_with_score(query, k=3)
for doc, score in results:
    print(f"相关度 {score:.3f}: {doc.page_content[:80]}...")

# === 3. 相似度搜索（带过滤）===
results = vector_store.similarity_search(
    query, k=5,
    filter={"category": "技术文档"}
)
''', lang='python')
add_text(slide, Inches(0.5), Inches(7.0), Inches(12), Inches(0.4),
         '💡 MaxKB 在 LangChain 之上做了封装，对开发者隐藏了 PGVector 细节',
         font_size=11, font_color=PURPLE, italic=True, bold=True)
add_footer(slide, page, TOTAL)


# ---- P15 LangChain 集成 ----
page = 15
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.9 LangChain · LLM 应用框架', font_size=40, font_color=PURPLE_DEEP, bold=True)
add_text(slide, Inches(0.5), Inches(2.0), Inches(12), Inches(0.6),
         'MaxKB 后端基于 LangChain 构建，LangChain 提供了标准化的 Chain / Agent / Tool / Retriever / Memory 抽象。',
         font_size=14, font_color=DARK_GRAY)

# LangChain 6 大核心组件
components = [
    ('Models', '模型层', PURPLE),
    ('Prompts', '提示词层', BLUE),
    ('Chains', '任务链层', GREEN),
    ('Retrievers', '检索层', PURPLE_DEEP),
    ('Agents', 'Agent 层', BLUE_DEEP),
    ('Memory', '记忆层', PURPLE_LIGHT),
]
for i, (en, zh, color) in enumerate(components):
    row, col = i // 3, i % 3
    x, y = Inches(0.5 + 4.2 * col), Inches(3.0 + 1.7 * row)
    add_rounded(slide, x, y, Inches(4.0), Inches(1.4), WHITE)
    rect = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, Inches(4.0), Inches(1.4))
    rect.fill.background()
    rect.line.color.rgb = color
    rect.line.width = Pt(2)
    rect.shadow.inherit = False
    add_text(slide, x, y + Inches(0.25), Inches(4.0), Inches(0.5),
             en, font_size=22, font_color=color, bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, x, y + Inches(0.85), Inches(4.0), Inches(0.4),
             zh, font_size=14, font_color=DARK_GRAY, align=PP_ALIGN.CENTER)

add_text(slide, Inches(0.5), Inches(6.8), Inches(12), Inches(0.4),
         '⚡ MaxKB 在这 6 层之上封装了「应用」「知识库」「工作流」三大业务概念',
         font_size=11, font_color=PURPLE, italic=True, bold=True)
add_footer(slide, page, TOTAL)


# ---- P16 模型中立 ----
page = 16
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.10 模型中立 · 一键切换', font_size=40, font_color=PURPLE_DEEP, bold=True)
add_text(slide, Inches(0.5), Inches(2.0), Inches(12), Inches(0.6),
         'MaxKB 支持市面上几乎所有主流大模型 · 模型中立让企业不被锁定',
         font_size=14, font_color=DARK_GRAY)
# 4 列
cols = [
    ('🇨🇳 国内', ['DeepSeek', '通义千问', '腾讯混元', '字节豆包', '百度千帆', '智谱 AI', 'Kimi', '硅基流动'], PURPLE),
    ('🌐 国外', ['OpenAI', 'Anthropic Claude', 'Google Gemini', 'Mistral', 'Llama', 'Qwen', 'Azure OpenAI'], BLUE),
    ('🏠 私有', ['Llama 3', 'Qwen 2', 'Mistral', 'ChatGLM', 'Baichuan', 'Yi', 'DeepSeek'], GREEN),
    ('🔧 多模态', ['GPT-4o', 'Claude 3.5 Sonnet', 'Gemini 1.5 Pro', 'Qwen-VL', 'GPT-4V'], PURPLE_DEEP),
]
for i, (title, models, color) in enumerate(cols):
    y = Inches(2.8)
    x = Inches(0.5 + 3.2 * i)
    add_rounded(slide, x, y, Inches(3.0), Inches(3.8), LIGHT_GRAY)
    add_rect(slide, x, y, Inches(3.0), Inches(0.5), color)
    add_text(slide, x, y + Inches(0.1), Inches(3.0), Inches(0.4),
             title, font_size=15, font_color=WHITE, bold=True, align=PP_ALIGN.CENTER)
    for j, m in enumerate(models):
        add_text(slide, x + Inches(0.2), y + Inches(0.7) + Inches(0.32) * j,
                 Inches(2.6), Inches(0.3),
                 '✓ ' + m, font_size=11, font_color=DARK_GRAY)
add_footer(slide, page, TOTAL)


# ---- P17 Workflow 可视化 ----
page = 17
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.11 Workflow · 可视化工作流', font_size=40, font_color=PURPLE_DEEP, bold=True)
slide.shapes.add_picture(f'{IMG_DIR}/03_工作流编排.png',
                         Inches(0.3), Inches(2.0), width=Inches(12.7))
add_text(slide, Inches(0.5), Inches(6.5), Inches(12), Inches(0.5),
         '💡 工作流让非程序员也能编排复杂 AI 业务，是 MaxKB 区别于普通 RAG 工具的核心特性',
         font_size=12, font_color=PURPLE_DEEP, italic=True, bold=True)
add_footer(slide, page, TOTAL)


# ---- P18 MCP 协议 ----
page = 18
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.12 MCP · 模型上下文协议', font_size=40, font_color=PURPLE_DEEP, bold=True)
slide.shapes.add_picture(f'{IMG_DIR}/05_MCP工具生态.png',
                         Inches(0.3), Inches(2.0), width=Inches(12.7))

add_text(slide, Inches(0.5), Inches(6.5), Inches(12), Inches(0.5),
         '⚡ MCP 让 LLM 能用标准化方式调用任何外部系统，把企业原有 CRM / ERP / 数据库全部纳入 LLM 工作流',
         font_size=12, font_color=PURPLE_DEEP, italic=True, bold=True)
add_footer(slide, page, TOTAL)


# ---- P19 Agent 范式 ----
page = 19
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.13 Agent · 从 RAG 到 Agent', font_size=40, font_color=PURPLE_DEEP, bold=True)

# 演进路径
stages = [
    ('Prompt', '直接问 LLM', MID_GRAY),
    ('RAG', '检索 + 生成', PURPLE),
    ('Harness', '工具调用', BLUE),
    ('Loop', '多轮迭代', PURPLE_DEEP),
    ('Agent', '自主规划', GREEN),
]
for i, (name, desc, color) in enumerate(stages):
    x = Inches(0.5 + 2.5 * i)
    y = Inches(3.0)
    add_rounded(slide, x, y, Inches(2.2), Inches(2.0), WHITE)
    rect = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, Inches(2.2), Inches(2.0))
    rect.fill.background()
    rect.line.color.rgb = color
    rect.line.width = Pt(2)
    rect.shadow.inherit = False
    add_text(slide, x, y + Inches(0.4), Inches(2.2), Inches(0.6),
             name, font_size=24, font_color=color, bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, x, y + Inches(1.1), Inches(2.2), Inches(0.6),
             desc, font_size=12, font_color=DARK_GRAY, align=PP_ALIGN.CENTER)
    if i < 4:
        add_text(slide, x + Inches(2.25), y + Inches(0.85), Inches(0.2), Inches(0.4),
                 '→', font_size=24, font_color=PURPLE, bold=True, align=PP_ALIGN.CENTER)

add_text(slide, Inches(0.5), Inches(5.5), Inches(12), Inches(0.5),
         '💡 MaxKB 已实现 RAG → Harness → Loop，Agent 模式通过 Workflow + MCP 工具组合即可达成',
         font_size=13, font_color=PURPLE_DEEP, italic=True, bold=True)
add_text(slide, Inches(0.5), Inches(6.2), Inches(12), Inches(0.6),
         '🎓 学术延伸：参考北大肖睿团队《Harness Engineering——驯服 Agent》69 页报告，了解前沿',
         font_size=12, font_color=MID_GRAY, italic=True)
add_footer(slide, page, TOTAL)


# ---- P20 技术栈剖析 ----
page = 20
slide = prs.slides.add_slide(blank_layout)
add_rect(slide, Inches(0), Inches(0), Inches(13.333), Inches(7.5), WHITE)
add_label(slide, Inches(0.5), Inches(0.4), 'PART 1 · 理论基座')
add_text(slide, Inches(0.5), Inches(1.0), Inches(12), Inches(0.8),
         '1.14 MaxKB 技术栈剖析', font_size=40, font_color=PURPLE_DEEP, bold=True)

stack = [
    ('Frontend', 'Vue.js', '前端 SPA 框架', PURPLE),
    ('Backend', 'Python · Django', '后端 Web 框架', BLUE),
    ('LLM Framework', 'LangChain', '大模型编排框架', PURPLE_DEEP),
    ('Database', 'PostgreSQL · pgvector', '关系型 + 向量数据库', BLUE_DEEP),
    ('Container', 'Docker', '容器化部署', GREEN),
    ('License', 'GPL v3', '开源协议', PURPLE_LIGHT),
]
# 6 个表格卡片
for i, (cat, tech, desc, color) in enumerate(stack):
    row, col = i // 3, i % 3
    x, y = Inches(0.5 + 4.2 * col), Inches(2.0 + 2.0 * row)
    add_rounded(slide, x, y, Inches(4.0), Inches(1.7), LIGHT_GRAY)
    add_rect(slide, x, y, Inches(0.1), Inches(1.7), color)
    add_text(slide, x + Inches(0.3), y + Inches(0.2), Inches(3.5), Inches(0.5),
             cat, font_size=12, font_color=MID_GRAY)
    add_text(slide, x + Inches(0.3), y + Inches(0.55), Inches(3.5), Inches(0.5),
             tech, font_size=18, font_color=color, bold=True)
    add_text(slide, x + Inches(0.3), y + Inches(1.1), Inches(3.5), Inches(0.5),
             desc, font_size=11, font_color=DARK_GRAY)
add_footer(slide, page, TOTAL)

print(f'✅ PART