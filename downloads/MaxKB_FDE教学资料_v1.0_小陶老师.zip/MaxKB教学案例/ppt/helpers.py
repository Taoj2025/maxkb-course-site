"""
MaxKB PPT 工具函数模块
被 gen_ppt.py 引用
"""

from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from lxml import etree

NSMAP = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}

def OxmlElement(name):
    """创建带命名空间的 XML Element 节点"""
    if ':' in name:
        prefix, local = name.split(':')
        ns = NSMAP.get(prefix, '')
        return etree.Element(f'{{{ns}}}{local}')
    return etree.Element(name)

# 紫色 AI 科技风配色
PURPLE_DEEP = RGBColor(0x5B, 0x2E, 0xBF)
PURPLE      = RGBColor(0x8B, 0x5C, 0xF6)
PURPLE_LIGHT = RGBColor(0xC4, 0xB5, 0xFD)
BLUE        = RGBColor(0x3B, 0x82, 0xF6)
BLUE_DEEP   = RGBColor(0x1E, 0x40, 0xAF)
BLUE_LIGHT  = RGBColor(0xBF, 0xDB, 0xFE)
DARK_GRAY   = RGBColor(0x37, 0x41, 0x51)
MID_GRAY    = RGBColor(0x6B, 0x72, 0x80)
LIGHT_GRAY  = RGBColor(0xF3, 0xF4, 0xF6)
WHITE       = RGBColor(0xFF, 0xFF, 0xFF)
YELLOW      = RGBColor(0xFC, 0xD3, 0x4D)
GREEN       = RGBColor(0x34, 0xD3, 0x99)


def set_run(run, font_name='微软雅黑', size=14, color=DARK_GRAY, bold=False, italic=False):
    """设置 run 字体（完整版本，含东亚字体处理）"""
    run.font.name = font_name
    run.font.size = Pt(size)
    run.font.color.rgb = color
    run.font.bold = bold
    run.font.italic = italic
    rPr = run._r.get_or_add_rPr()
    for rFont in rPr.findall(qn('a:rFonts')):
        rPr.remove(rFont)
    rFonts = OxmlElement('a:rFonts')
    rFonts.set('eastAsia', font_name)
    rFonts.set('ascii', font_name)
    rFonts.set('hAnsi', font_name)
    rPr.append(rFonts)


def add_rect(slide, x, y, w, h, fill_color):
    """矩形 + 实色填充"""
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    shape.line.fill.background()
    shape.shadow.inherit = False
    return shape


def add_rounded(slide, x, y, w, h, fill_color):
    """圆角矩形"""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    shape.line.fill.background()
    shape.shadow.inherit = False
    return shape


def add_circle(slide, cx, cy, r, color):
    """圆形"""
    shape = slide.shapes.add_shape(MSO_SHAPE.OVAL, cx - r, cy - r, r*2, r*2)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    shape.shadow.inherit = False
    return shape


def add_text(slide, x, y, w, h, text, font_size=14, font_color=DARK_GRAY,
             font_name='微软雅黑', bold=False, italic=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP):
    """纯文本框"""
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = Emu(0)
    tf.margin_right = Emu(0)
    tf.margin_top = Emu(0)
    tf.margin_bottom = Emu(0)
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    set_run(run, font_name, font_size, font_color, bold, italic)
    return tb


def add_multiline(slide, x, y, w, h, lines, font_size=12, font_color=DARK_GRAY,
                  font_name='微软雅黑', line_spacing=1.5, align=PP_ALIGN.LEFT):
    """多行文本（list of strings）"""
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Emu(0)
    tf.margin_right = Emu(0)
    tf.margin_top = Emu(0)
    tf.margin_bottom = Emu(0)
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.line_spacing = line_spacing
        run = p.add_run()
        run.text = ln
        set_run(run, font_name, font_size, font_color)
    return tb


def add_label(slide, x, y, text, fill_color=PURPLE, font_color=WHITE, font_size=10):
    """左上角章节标签"""
    w = Inches(2.4)
    h = Inches(0.28)
    shape = add_rect(slide, x, y, w, h, fill_color)
    tf = shape.text_frame
    tf.margin_left = Emu(0)
    tf.margin_right = Emu(0)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    run = p.add_run()
    run.text = text
    set_run(run, '微软雅黑', font_size, font_color, bold=True)


def add_footer(slide, page_num, total='64'):
    """底部品牌行 + 页码"""
    add_text(slide, Inches(0.6), Inches(7.1), Inches(10), Inches(0.3),
             '企业级智能体平台 · MaxKB 教学课件  ·  小陶老师  ·  2026',
             font_size=9, font_color=MID_GRAY)
    add_text(slide, Inches(12.0), Inches(7.1), Inches(1.2), Inches(0.3),
             f'{page_num} / {total}',
             font_size=9, font_color=MID_GRAY, align=PP_ALIGN.RIGHT)


def add_card(slide, x, y, w, h, title, content_list, accent_color=PURPLE,
             title_size=14, content_size=11):
    """信息卡片（左 accent bar + 标题 + 项目符号列表）"""
    add_rounded(slide, x, y, w, h, LIGHT_GRAY)
    add_rect(slide, x, y, Inches(0.08), h, accent_color)
    add_text(slide, x + Inches(0.25), y + Inches(0.15), w - Inches(0.4), Inches(0.4),
             title, font_size=title_size, font_color=accent_color, bold=True)
    for i, item in enumerate(content_list):
        add_text(slide, x + Inches(0.25), y + Inches(0.6) + Inches(0.32) * i,
                 w - Inches(0.4), Inches(0.3),
                 '• ' + item, font_size=content_size, font_color=DARK_GRAY)


def add_section_cover(slide, part_label, part_title, page_num, total='64', subtitle=''):
    """章节封面：左 30% 紫色实色 + 右 70% 米白"""
    add_rect(slide, Inches(0), Inches(0), Inches(4.5), Inches(7.5), PURPLE_DEEP)
    add_text(slide, Inches(0.4), Inches(2.5), Inches(4), Inches(1.5),
             part_label, font_size=72, font_color=WHITE, bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, Inches(0.4), Inches(3.8), Inches(4), Inches(0.5),
             part_title.split('·')[-1].strip() if '·' in part_title else part_title,
             font_size=18, font_color=PURPLE_LIGHT, align=PP_ALIGN.CENTER)
    add_rect(slide, Inches(4.5), Inches(0), Inches(8.833), Inches(7.5), WHITE)
    add_text(slide, Inches(5.0), Inches(2.5), Inches(8), Inches(0.8),
             'PART ' + part_label, font_size=24, font_color=PURPLE_DEEP, bold=True)
    add_text(slide, Inches(5.0), Inches(3.2), Inches(8), Inches(0.8),
             part_title, font_size=24, font_color=DARK_GRAY, bold=True)
    if subtitle:
        add_multiline(slide, Inches(5.0), Inches(4.2), Inches(8), Inches(2.5),
                      subtitle.split('\n'), font_size=13, font_color=MID_GRAY,
                      line_spacing=1.5)
    add_rect(slide, Inches(5.0), Inches(4.0), Inches(1.0), Inches(0.05), PURPLE)


def add_code(slide, x, y, w, h, code, lang='bash'):
    """代码块：浅灰底 + 顶部 lang 标签 + 行号"""
    add_rounded(slide, x, y, w, h, LIGHT_GRAY)
    add_rect(slide, x, y, w, Inches(0.28), PURPLE)
    add_text(slide, x + Inches(0.15), y + Inches(0.04), Inches(2), Inches(0.25),
             f'▶ {lang.upper()}', font_size=10, font_color=WHITE, bold=True)
    code_tb = slide.shapes.add_textbox(x + Inches(0.15), y + Inches(0.35),
                                       w - Inches(0.3), h - Inches(0.45))
    tf = code_tb.text_frame
    tf.word_wrap = False
    tf.margin_left = Emu(0)
    tf.margin_top = Emu(0)
    tf.margin_bottom = Emu(0)
    lines = code.strip().split('\n')
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        ln_run = p.add_run()
        ln_run.text = f'{i+1:>3}  '
        set_run(ln_run, 'Fira Code', 9, MID_GRAY)
        code_run = p.add_run()
        code_run.text = line
        set_run(code_run, 'Fira Code', 10, DARK_GRAY)


def add_pill_badge(slide, x, y, w, h, text, fill_color, font_color=WHITE):
    """胶囊徽章"""
    shape = add_rounded(slide, x, y, w, h, fill_color)
    tf = shape.text_frame
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    run = p.add_run()
    run.text = text
    set_run(run, '微软雅黑', 11, font_color, bold=True)
