"""
生成 MaxKB 教学配图 - 6 张
1. MaxKB 五维能力雷达图
2. RAG 原理流程图
3. 工作流编排示意图
4. 三层架构图（前端 / 后端 / 大模型）
5. MCP 工具生态图
6. 5 大场景业务价值矩阵
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle
import numpy as np
import os

# 字体支持中文
plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'WenQuanYi Micro Hei', 'PingFang SC', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

OUTPUT_DIR = "/root/.openclaw/workspace/projects/MaxKB教学案例/images"

# 紫色 AI 科技风配色
PURPLE_DEEP = '#5B2EBF'
PURPLE = '#8B5CF6'
BLUE = '#3B82F6'
BLUE_DEEP = '#1E40AF'
LIGHT_PURPLE = '#C4B5FD'
LIGHT_BLUE = '#BFDBFE'
GRAY = '#374151'
LIGHT_GRAY = '#F3F4F6'


# ============================================================
# 图 1：MaxKB 五维能力雷达图
# ============================================================
def fig1_radar():
    fig, ax = plt.subplots(figsize=(8, 6), dpi=120, subplot_kw=dict(polar=True))

    categories = ['RAG 检索', '工作流', 'MCP 工具', '模型中立', '多模态']
    values = [95, 88, 85, 92, 80]
    values += values[:1]

    angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]

    ax.fill(angles, values, color=PURPLE, alpha=0.35)
    ax.plot(angles, values, color=PURPLE_DEEP, linewidth=2.5)
    ax.scatter(angles, values, color=PURPLE_DEEP, s=80, zorder=10)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=11, color=GRAY)
    ax.set_ylim(0, 100)
    ax.set_yticks([20, 40, 60, 80, 100])
    ax.set_yticklabels(['20', '40', '60', '80', '100'], fontsize=9, color='gray')
    ax.grid(color='lightgray', linestyle='--', linewidth=0.8)

    plt.title('MaxKB 五维核心能力', fontsize=16, fontweight='bold', color=PURPLE_DEEP, pad=20)
    plt.tight_layout()
    plt.savefig(f'{OUTPUT_DIR}/01_五维能力雷达图.png', bbox_inches='tight', dpi=120, facecolor='white')
    plt.close()
    print('✅ 图1：五维能力雷达图')


# ============================================================
# 图 2：RAG 原理流程图
# ============================================================
def fig2_rag():
    fig, ax = plt.subplots(figsize=(11, 5), dpi=120)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 6)
    ax.axis('off')

    # 标题
    ax.text(6, 5.5, 'RAG 检索增强生成原理', ha='center', fontsize=18, fontweight='bold', color=PURPLE_DEEP)

    # 流程节点
    nodes = [
        (1.0, 3.0, '用户提问', LIGHT_BLUE, BLUE_DEEP),
        (3.5, 3.0, '向量化查询', LIGHT_PURPLE, PURPLE_DEEP),
        (6.0, 3.0, '向量检索\nTop-K', '#FFE4B5', '#B8860B'),
        (8.5, 3.0, 'Prompt 组装', LIGHT_BLUE, BLUE_DEEP),
        (11.0, 3.0, 'LLM 生成回答', LIGHT_PURPLE, PURPLE_DEEP),
    ]

    for x, y, text, bg, ec in nodes:
        box = FancyBboxPatch((x-0.8, y-0.5), 1.6, 1.0,
                              boxstyle="round,pad=0.05", linewidth=2,
                              edgecolor=ec, facecolor=bg)
        ax.add_patch(box)
        ax.text(x, y, text, ha='center', va='center', fontsize=11, fontweight='bold', color=ec)

    # 箭头
    arrows = [(1.8, 3.0, 2.7, 3.0), (4.3, 3.0, 5.2, 3.0),
              (6.8, 3.0, 7.7, 3.0), (9.3, 3.0, 10.2, 3.0)]
    for x1, y1, x2, y2 in arrows:
        arrow = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='->,head_width=0.5',
                                 color=PURPLE, linewidth=2.5)
        ax.add_patch(arrow)

    # 底部说明
    ax.text(6, 1.5, '⚡ 关键：先检索再生成，避免 LLM 幻觉，所有回答均基于真实文档', 
            ha='center', fontsize=11, color=GRAY, style='italic')
    ax.text(6, 0.8, '召回 → 重排 → 上下文 → LLM', ha='center', fontsize=10, color='gray')

    plt.savefig(f'{OUTPUT_DIR}/02_RAG原理流程图.png', bbox_inches='tight', dpi=120, facecolor='white')
    plt.close()
    print('✅ 图2：RAG 原理流程图')


# ============================================================
# 图 3：工作流编排示意
# ============================================================
def fig3_workflow():
    fig, ax = plt.subplots(figsize=(11, 6), dpi=120)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 7)
    ax.axis('off')

    ax.text(6, 6.4, 'MaxKB 可视化工作流编排', ha='center', fontsize=18, fontweight='bold', color=PURPLE_DEEP)

    # 节点
    nodes = [
        (1.5, 4.5, '开始', '#FFE4E1', '#C0392B', 'circle'),
        (4, 4.5, '问题分类\n(LLM)', LIGHT_PURPLE, PURPLE_DEEP, 'rect'),
        (7, 5.5, '知识库\n查询', LIGHT_BLUE, BLUE_DEEP, 'rect'),
        (7, 3.5, '工单\n创建', '#FFE4B5', '#B8860B', 'rect'),
        (10, 4.5, '结束', '#D5F5E3', '#1E8449', 'circle'),
    ]

    for x, y, text, bg, ec, shape in nodes:
        if shape == 'circle':
            c = Circle((x, y), 0.6, facecolor=bg, edgecolor=ec, linewidth=2.5)
            ax.add_patch(c)
            ax.text(x, y, text, ha='center', va='center', fontsize=11, fontweight='bold', color=ec)
        else:
            box = FancyBboxPatch((x-0.9, y-0.5), 1.8, 1.0,
                                  boxstyle="round,pad=0.05", linewidth=2,
                                  edgecolor=ec, facecolor=bg)
            ax.add_patch(box)
            ax.text(x, y, text, ha='center', va='center', fontsize=10, fontweight='bold', color=ec)

    # 连线
    arrows = [
        (2.1, 4.5, 3.1, 4.5, '业务问题'),
        (4.9, 4.8, 6.1, 5.5, '咨询类'),
        (4.9, 4.2, 6.1, 3.5, '投诉类'),
        (7.9, 5.5, 9.4, 4.7, ''),
        (7.9, 3.5, 9.4, 4.3, ''),
    ]
    for x1, y1, x2, y2, label in arrows:
        arrow = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='->,head_width=0.4',
                                 color=PURPLE, linewidth=2)
        ax.add_patch(arrow)
        if label:
            ax.text((x1+x2)/2 + 0.2, (y1+y2)/2, label, fontsize=9, color=GRAY, style='italic')

    # 底部说明
    ax.text(6, 1.2, '⚡ 拖拽节点即可编排复杂业务流 · 支持自定义函数节点 / 条件分支 / 循环',
            ha='center', fontsize=11, color=GRAY, style='italic')

    plt.savefig(f'{OUTPUT_DIR}/03_工作流编排.png', bbox_inches='tight', dpi=120, facecolor='white')
    plt.close()
    print('✅ 图3：工作流编排')


# ============================================================
# 图 4：三层架构图
# ============================================================
def fig4_architecture():
    fig, ax = plt.subplots(figsize=(10, 7), dpi=120)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')

    ax.text(6, 7.3, 'MaxKB 三层技术架构', ha='center', fontsize=18, fontweight='bold', color=PURPLE_DEEP)

    layers = [
        (5.5, '应用层 · Vue.js', '前端 Web 控制台  /  嵌入式问答组件  /  对话调试界面', PURPLE, 'white'),
        (3.5, '服务层 · Python + Django + LangChain', 'RAG Pipeline  /  Workflow Engine  /  MCP Client  /  API 网关', BLUE_DEEP, 'white'),
        (1.5, '基础层 · PostgreSQL + pgvector + LLM', '向量数据库  /  文档存储  /  DeepSeek / OpenAI / Claude / Qwen', '#2C3E50', 'white'),
    ]

    for y, title, desc, color, fg in layers:
        box = FancyBboxPatch((1, y-0.8), 10, 1.6,
                              boxstyle="round,pad=0.05", linewidth=2,
                              edgecolor=color, facecolor=color, alpha=0.85)
        ax.add_patch(box)
        ax.text(6, y+0.2, title, ha='center', va='center', fontsize=14, fontweight='bold', color=fg)
        ax.text(6, y-0.3, desc, ha='center', va='center', fontsize=10, color=fg)

    # 箭头表示数据流
    for y in [4.5, 2.5]:
        arrow = FancyArrowPatch((6, y), (6, y-0.5), arrowstyle='->,head_width=0.4',
                                 color=PURPLE_DEEP, linewidth=2.5)
        ax.add_patch(arrow)

    plt.savefig(f'{OUTPUT_DIR}/04_三层架构图.png', bbox_inches='tight', dpi=120, facecolor='white')
    plt.close()
    print('✅ 图4：三层架构图')


# ============================================================
# 图 5：MCP 工具生态
# ============================================================
def fig5_mcp():
    fig, ax = plt.subplots(figsize=(11, 7), dpi=120)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')

    ax.text(6, 7.3, 'MCP 工具生态全景', ha='center', fontsize=18, fontweight='bold', color=PURPLE_DEEP)

    # 中心 - LLM Agent
    center = Circle((6, 4), 1.2, facecolor=PURPLE, edgecolor=PURPLE_DEEP, linewidth=3)
    ax.add_patch(center)
    ax.text(6, 4, 'LLM Agent\n(MaxKB)', ha='center', va='center', fontsize=12, fontweight='bold', color='white')

    # 周围 8 个 MCP Server
    import math
    servers = [
        ('CRM\n系统', 0.4, 0.4),
        ('ERP\n系统', 0.4, 0.4),
        ('数据库\n(MySQL)', 0.4, 0.4),
        ('邮件\n服务', 0.4, 0.4),
        ('日历\n工具', 0.4, 0.4),
        ('搜索\n引擎', 0.4, 0.4),
        ('自定义\nAPI', 0.4, 0.4),
        ('Slack\n工作区', 0.4, 0.4),
    ]

    for i, (text, _, _) in enumerate(servers):
        angle = math.pi / 4 * i + math.pi / 8
        x = 6 + 4 * math.cos(angle)
        y = 4 + 2.5 * math.sin(angle)
        box = FancyBboxPatch((x-0.85, y-0.5), 1.7, 1.0,
                              boxstyle="round,pad=0.05", linewidth=1.5,
                              edgecolor=BLUE, facecolor=LIGHT_BLUE)
        ax.add_patch(box)
        ax.text(x, y, text, ha='center', va='center', fontsize=10, fontweight='bold', color=BLUE_DEEP)
        arrow = FancyArrowPatch((6, 4), (x, y), arrowstyle='->,head_width=0.3',
                                 color=PURPLE, linewidth=1.2, alpha=0.6)
        ax.add_patch(arrow)

    plt.savefig(f'{OUTPUT_DIR}/05_MCP工具生态.png', bbox_inches='tight', dpi=120, facecolor='white')
    plt.close()
    print('✅ 图5：MCP 工具生态')


# ============================================================
# 图 6：5 大场景业务价值
# ============================================================
def fig6_scenarios():
    fig, ax = plt.subplots(figsize=(12, 6.5), dpi=120)

    scenarios = ['高校客服', '教师备课', '文献精读', '企业知识库', '医院导诊']
    deployment_weeks = [1, 2, 0.5, 2, 3]
    roi_score = [9.2, 8.5, 9.5, 9.0, 8.8]
    difficulty = [2, 4, 2, 4, 5]

    x = np.arange(len(scenarios))
    width = 0.25

    bars1 = ax.bar(x - width, deployment_weeks, width, label='实施周期 (周)', color=PURPLE, alpha=0.85)
    bars2 = ax.bar(x, roi_score, width, label='ROI 评分 (满分10)', color=BLUE, alpha=0.85)
    bars3 = ax.bar(x + width, difficulty, width, label='实施难度 (1-5)', color='#B8860B', alpha=0.85)

    for bars in [bars1, bars2, bars3]:
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{height}', ha='center', va='bottom', fontsize=9, color=GRAY)

    ax.set_xticks(x)
    ax.set_xticklabels(scenarios, fontsize=12, color=GRAY)
    ax.set_ylabel('评分 / 周数', fontsize=12, color=GRAY)
    ax.set_title('5 大企业场景业务价值对比', fontsize=16, fontweight='bold', color=PURPLE_DEEP, pad=15)
    ax.legend(loc='upper right', fontsize=10, frameon=True)
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    ax.set_axisbelow(True)

    plt.tight_layout()
    plt.savefig(f'{OUTPUT_DIR}/06_五大场景对比.png', bbox_inches='tight', dpi=120, facecolor='white')
    plt.close()
    print('✅ 图6：5 大场景对比')


# 主执行
if __name__ == '__main__':
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fig1_radar()
    fig2_rag()
    fig3_workflow()
    fig4_architecture()
    fig5_mcp()
    fig6_scenarios()
    print(f'\n📁 输出目录：{OUTPUT_DIR}')
    print(f'📊 共生成 6 张配图')
